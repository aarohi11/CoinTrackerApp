package com.cointrackerapp.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "address")
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	private int id;
	
	@Column(name = "address_hex")
	private String addressHex;
	
	@Column(name = "balance")
	private double balance;
	
	@Column(name = "amount_sent")
	private double amountSent;
	
	@Column(name = "amount_recieved")
	private double amountRecieved;
	
	@Column(name = "archive_status")
	private int archiveStatus;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddressHex() {
		return addressHex;
	}

	public void setAddressHex(String addressHex) {
		this.addressHex = addressHex;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getAmountSent() {
		return amountSent;
	}

	public void setAmountSent(double amountSent) {
		this.amountSent = amountSent;
	}

	public double getAmountRecieved() {
		return amountRecieved;
	}

	public void setAmountRecieved(double amountRecieved) {
		this.amountRecieved = amountRecieved;
	}	
	
	public int getArchiveStatus() {
		return archiveStatus;
	}

	public void setArchiveStatus(int archiveStatus) {
		this.archiveStatus = archiveStatus;
	}
	
}
