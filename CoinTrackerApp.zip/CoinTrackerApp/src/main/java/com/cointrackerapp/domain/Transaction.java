package com.cointrackerapp.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "transaction")
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Transaction
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	private int id;
	
	@Column(name = "transaction_hex")
	private String transactionHex;
	
	@Column(name = "sender_address")
	private String senderAddress;
	
	@Column(name = "reciever_address")
	private String recieverAddress;
	
	@Column(name = "amount_sent")
	private double amountSent;
	
	@Column(name = "amount_recieved")
	private double amountRecieved;
	
	@Column(name = "transaction_fee")
	private double transactionFee;
	
	@Column(name = "transaction_date")
	private LocalDate transactionDate;
	
	@Column(name = "archive_status")
	private int archiveStatus;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTransactionHex() {
		return transactionHex;
	}

	public void setTransactionHex(String transactionHex) {
		this.transactionHex = transactionHex;
	}

	public String getSenderAddress() {
		return senderAddress;
	}

	public void setSenderAddress(String senderAddress) {
		this.senderAddress = senderAddress;
	}

	public String getRecieverAddress() {
		return recieverAddress;
	}

	public void setRecieverAddress(String recieverAddress) {
		this.recieverAddress = recieverAddress;
	}

	public double getAmountSent() {
		return amountSent;
	}

	public void setAmountSent(double amountSent) {
		this.amountSent = amountSent;
	}

	public double getAmountRecieved() {
		return amountRecieved;
	}

	public void setAmountRecieved(double amountRecieved) {
		this.amountRecieved = amountRecieved;
	}

	public double getTransactionFee() {
		return transactionFee;
	}

	public void setTransactionFee(double transactionFee) {
		this.transactionFee = transactionFee;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public int getArchiveStatus() {
		return archiveStatus;
	}

	public void setArchiveStatus(int archiveStatus) {
		this.archiveStatus = archiveStatus;
	}
}
