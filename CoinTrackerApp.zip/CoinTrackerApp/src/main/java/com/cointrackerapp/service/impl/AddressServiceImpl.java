package com.cointrackerapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cointrackerapp.domain.Address;
import com.cointrackerapp.repository.AddressRepository;
import com.cointrackerapp.service.AddressService;

@Service
public class AddressServiceImpl implements AddressService{

	private final AddressRepository addressRepository;
	
	@Autowired
	public AddressServiceImpl(AddressRepository addressRepository) {
		this.addressRepository = addressRepository;
	}

	@Override
	public List<Address> getAllAddresses() {
		System.out.println("Inside Service:"+addressRepository.getAllAddresses());
		return addressRepository.getAllAddresses();
	}

	@Override
	public Address findByAddress(String addressHex) {
		System.out.println("Inside Service:"+addressRepository.findByAddress(addressHex));
		return addressRepository.findByAddress(addressHex);
	}

	@Override
	public void deleteByAddress(String addressHex) {
		addressRepository.deleteByAddress(addressHex);	
	}


}
