package com.cointrackerapp.service;

import java.util.List;

import com.cointrackerapp.domain.Address;

public interface AddressService {
	public List<Address> getAllAddresses();

	public Address findByAddress(String addressHex);

	public void deleteByAddress(String addressHex); 
}
