package com.cointrackerapp.service;

import java.util.List;

import com.cointrackerapp.domain.Transaction;

public interface TransactionService {

	List<Transaction> getAllTransactionsByAddress(String addressHex);
	public void deleteTransactionByAddress(String addressHex); 
}
