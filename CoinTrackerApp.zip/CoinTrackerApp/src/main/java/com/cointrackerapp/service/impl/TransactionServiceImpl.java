package com.cointrackerapp.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cointrackerapp.domain.Transaction;
import com.cointrackerapp.repository.AddressRepository;
import com.cointrackerapp.repository.TransactionRepository;
import com.cointrackerapp.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService{

	private final TransactionRepository transactionRepository;
	
	@Autowired
	public TransactionServiceImpl(TransactionRepository transactionRepository) {
		this.transactionRepository = transactionRepository;
	}

	@Override
	public List<Transaction> getAllTransactionsByAddress(String addressHex) {
		System.out.println("Inside get All Transactions by address:"+transactionRepository.findByAddress(addressHex));
		return transactionRepository.findByAddress(addressHex);
	}

	@Override
	public void deleteTransactionByAddress(String addressHex) {
		this.transactionRepository.deleteByAddress(addressHex);
	}


}
