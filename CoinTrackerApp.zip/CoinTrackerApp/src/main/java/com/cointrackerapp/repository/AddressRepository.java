package com.cointrackerapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cointrackerapp.domain.Address;

@Transactional
@Repository
public interface AddressRepository extends JpaRepository<Address,Integer>
{
	@Modifying
	   @Transactional
	   @Query("FROM Address a where a.archiveStatus=1")
	   List <Address> getAllAddresses();
	
	   @Query("From Address a where a.addressHex=?1")
	   Address findByAddress(String addressHex);
	   
	   @Modifying
	   @Transactional
	   @Query("update Address a set a.archiveStatus = 0 where a.addressHex = ?1")
	   void deleteByAddress(String addressHex);
}