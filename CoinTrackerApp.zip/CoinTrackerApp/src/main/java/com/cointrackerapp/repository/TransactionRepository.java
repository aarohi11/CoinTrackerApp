package com.cointrackerapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cointrackerapp.domain.Transaction;


@Transactional
@Repository
public interface TransactionRepository extends JpaRepository<Transaction,Integer>
{
	@Modifying
	@Transactional
	@Query("From Transaction t where t.senderAddress=?1 or t.recieverAddress=?1 and t.archiveStatus=1 order by t.transactionDate DESC")
	List<Transaction> findByAddress(String addressHex);
	
	 @Modifying
	   @Transactional
	   @Query("update Transaction t set t.archiveStatus = 0 where t.senderAddress=?1 or t.recieverAddress=?1")
	   void deleteByAddress(String addressHex);
}