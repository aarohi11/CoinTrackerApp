package com.cointrackerapp.controller;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cointrackerapp.domain.Address;
import com.cointrackerapp.domain.Transaction;
import com.cointrackerapp.repository.AddressRepository;
import com.cointrackerapp.repository.TransactionRepository;
import com.cointrackerapp.service.AddressService;
import com.cointrackerapp.service.TransactionService;


@CrossOrigin(origins = {"http://localhost:4200"},allowedHeaders="*")
@RestController
@RequestMapping("/transaction")
public class TransactionController {
	
	private final TransactionService transactionService;
	private final TransactionRepository transactionRepo;
	private final AddressService addressService;
	private final AddressRepository addressRepo;
	
	@Autowired
	public TransactionController(TransactionService transactionService, TransactionRepository transactionRepo, AddressService addressService, AddressRepository addressRepo) {
		this.transactionService = transactionService;
		this.transactionRepo = transactionRepo;
		this.addressService = addressService;
		this.addressRepo = addressRepo;
	}
	
	@CrossOrigin(origins = {"http://localhost:4200"},allowedHeaders="*")
	@RequestMapping(value="/postTransaction",method=RequestMethod.POST)
	public @ResponseBody String createTransaction(@RequestBody Transaction transaction) 
	{
		 System.out.println("\n Inside create transaction:"+transaction);
		 String transactionHex = RandomStringUtils.randomAlphanumeric(32);
		 transaction.setTransactionHex(transactionHex);
		 transaction.setTransactionDate(LocalDate.now());
		 this.transactionRepo.save(transaction);
		 double transactionAmount = transaction.getAmountSent();
		 double transactionFee = transaction.getTransactionFee();
		 updateSenderAmount(transactionAmount, transaction.getSenderAddress(), transactionFee);
		 updateRecieverAmount(transactionAmount, transaction.getRecieverAddress());
		 return "Address generated successfully";
    }
	
	public void updateSenderAmount(double transactionAmount, String senderAddress, double transactionFee) {
		Address sender = addressService.findByAddress(senderAddress);
		sender.setBalance(sender.getBalance()-sender.getAmountSent()-transactionFee);
		sender.setAmountSent(sender.getAmountSent()+transactionAmount);
		addressRepo.save(sender);
	}
	
	public void updateRecieverAmount(double transactionAmount, String recieverAddress) {
		Address reciever = addressService.findByAddress(recieverAddress);
		reciever.setAmountRecieved(reciever.getAmountRecieved()+transactionAmount);
		addressRepo.save(reciever);
	}
	
	@CrossOrigin(origins = {"http://localhost:4200"},allowedHeaders="*")
	@RequestMapping(value="/getAllTransactions/{id}",method=RequestMethod.GET)
    @ResponseBody
    public List<Transaction> getAllTransactionsByAddress(@PathVariable("id") String addressHex)
    {
		System.out.println("Inside getAllTransactionsByAddress:");
		return transactionService.getAllTransactionsByAddress(addressHex);	
    }
}
