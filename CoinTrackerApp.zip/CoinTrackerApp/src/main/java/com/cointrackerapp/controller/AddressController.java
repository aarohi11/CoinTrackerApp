package com.cointrackerapp.controller;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cointrackerapp.domain.Address;
import com.cointrackerapp.repository.AddressRepository;
import com.cointrackerapp.service.AddressService;
import com.cointrackerapp.service.TransactionService;


@CrossOrigin(origins = {"http://localhost:4200"},allowedHeaders="*")
@RestController
@RequestMapping("/address")
public class AddressController {
	
	private final AddressService addressService;
	private final AddressRepository addressRepo;
	private final TransactionService transactionService;
	
	int length;
	
	@Autowired
	public AddressController(AddressService addressService, AddressRepository addressRepo, TransactionService transactionService) {
		this.addressService = addressService;
		this.addressRepo = addressRepo;
		this.transactionService = transactionService;
	}
	
	@CrossOrigin(origins = {"http://localhost:4200"},allowedHeaders="*")
	@RequestMapping(value="/postlen",method=RequestMethod.POST)
	public @ResponseBody String getAddressLen(@RequestBody int length) 
	{
		 System.out.println("\n Inside generate address:");
		 this.length = length;
		 System.out.println("Lenght is:"+this.length);
		 return "Length recieved successfully";
    }
	
	@CrossOrigin(origins = {"http://localhost:4200"},allowedHeaders="*")
	@RequestMapping(value="/postAddress",method=RequestMethod.POST)
	public @ResponseBody String generateNewAddress(@RequestBody Address address) 
	{
		 System.out.println("\n Inside generate address:"+address);
		 String generatedAddress = RandomStringUtils.randomAlphanumeric(this.length);
		 address.setAddressHex(generatedAddress);
		 this.addressRepo.save(address);
		 return "Address generated successfully";
    }
	
	@CrossOrigin(origins = "http://localhost:4200",allowedHeaders="*")
	@RequestMapping(value = "/getAllAddresses", method = RequestMethod.GET)
	@ResponseBody // to send list of objects in JSON form
	public List<Address> getAllAddresses() {
		System.out.println("Inside getAllAddresses");
		return addressService.getAllAddresses();
	}
	
	@RequestMapping(value = "/deleteAddress", method = RequestMethod.POST)
	@ResponseBody
	public void deleteByAddress(@RequestBody String addressHex) 
	{
		System.out.println("\n Inside delete Address"+addressHex);
		addressService.deleteByAddress(addressHex);
		transactionService.deleteTransactionByAddress(addressHex);
	}
}
