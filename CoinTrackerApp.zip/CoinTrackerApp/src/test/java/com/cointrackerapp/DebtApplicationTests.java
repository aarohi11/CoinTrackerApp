package com.cointrackerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DebtApplicationTests 
{

	@Test
	void contextLoads() 
	{
	}

}